<?php $__env->startSection('titulopagina'); ?>
    Información del libro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <table class="table">
        <thead class="table-dark">
            <tr>
                <td>Título:</td>
                <td>Descripción:</td>
                <td>Fecha de publicación:</td>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td><?php echo e($book->titulo); ?></td>
                <td><?php echo e($book->descripcion); ?></td>
                <td><?php echo e($book->fechapub); ?></td>
            </tr>
            <tr>
                <div class="alert alert-success">
                Este libro ha sido accedido <?php echo e(session('contador')); ?> veces.
                </div>
            </tr>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('book.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/book/show.blade.php ENDPATH**/ ?>