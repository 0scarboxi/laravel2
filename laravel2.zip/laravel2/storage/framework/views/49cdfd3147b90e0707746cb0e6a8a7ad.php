<?php $__env->startSection('titulopagina'); ?>
    Listado General de clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php if(session('exito')): ?>
<br>
<div class="alert alert-success">
    <?php echo e(session('exito')); ?>

</div>
<?php endif; ?>

<table class="table">
    <thead class="table-dark">
        <tr>
            <td>ID</td>
            <td>Cliente Rut</td>
            <td>Fecha</td>
            <td>Descuento</td>
            <td>Monto_final</td>
            <td></td>
            <td></td>
        </tr>
    </thead>

    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($venta->id); ?></td>
            <td><?php echo e($venta->cliente_rut); ?></td>
            <td><?php echo e($venta->fecha); ?></td>
            <td><?php echo e($venta->descuento); ?></td>
            <td><?php echo e($venta->monto_final); ?></td>
           <td>
                <form action="<?php echo e(route('ventas.destroy',$venta->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" onclick="return confirm('¿Deseas Borrarlo?');" type="submit">Borrar</button>
                </form> 
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-danger">
            No se han encontrado clientes.
        </div>
    <?php endif; ?>
</tbody>

    
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('venta.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel2\resources\views/venta/index.blade.php ENDPATH**/ ?>