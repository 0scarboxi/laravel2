    
    <?php $__env->startSection('titulopagina'); ?>
        Creaccion del libro
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('contenido'); ?>
     <!-- Contact Section Form-->
     <div class="row justify-content-center">
                    <div class="col-lg-8 col-xl-7">
                        <br><br>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <br>

                        <form action="<?php echo e(route('books.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <!-- Titulo input-->
                            <div class="form-floating mb-3">
                                <input class="form-control" name="titulo" type="text" value="<?php echo e(old('titulo')); ?>"/>
                                <label for="name">Titulo</label>
                                <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Autor input-->
                            <div class="form-floating mb-3">
                                <input class="form-control" name="descripcion" type="text" value="<?php echo e(old('descripcion')); ?>" />
                                <label for="name">Autor</label>
                            </div>
                            <!-- Fecha pub input-->
                            <div class="form-floating mb-3">
                                <input class="form-control" name="fechapub" type="date" value="<?php echo e(old('fechapub')); ?>" />
                                <label for="name">Fecha Publicacion</label>
                            </div>
                            <!-- Fecha pub GENERO-->
                            <div class="form-floating mb-3">
                                <input class="form-control" name="genero" type="text" value="<?php echo e(old('genero')); ?>" />
                                <label for="name">Genero</label>
                            </div>
                            <!-- Fecha pub NUMPAG-->
                            <div class="form-floating mb-3">
                                <input class="form-control" name="numpag" type="number" value="<?php echo e(old('numpag')); ?>" />
                                <label for="name">Numero de paginas</label>
                            </div>
                            
                            <!-- Submit Button-->
                            <button class="btn btn-primary" type="submit">Crear Libro</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('book.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/book/create.blade.php ENDPATH**/ ?>