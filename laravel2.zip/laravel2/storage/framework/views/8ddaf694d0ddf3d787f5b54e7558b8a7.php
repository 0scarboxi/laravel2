    
    <?php $__env->startSection('titulopagina'); ?>
        Listado General de libro
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('contenido'); ?>
    <br>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isUser')): ?>
    <a class="btn btn-primary" href="<?php echo e(route('books.create')); ?>">Crear Libro</a>
    <?php endif; ?>
    <br>
    <br>
    
    <?php if(session('exito')): ?>
    <br>
    <div class="alert alert-success">
        <?php echo e(session('exito')); ?>

    </div>
    <?php endif; ?>

    <table class="table">
        <thead class="table-dark">
            <tr>
                <td>Titulo:</td>
                <td>Autor:</td>
                <td>Fecha de publicacion:</td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </thead>

        <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($book->titulo); ?></td>
                    <td><?php echo e($book->descripcion); ?></td>
                    <td><?php echo e($book->fechapub); ?></td>
                    <td><a class="btn btn-primary" href="/books/<?php echo e($book->id); ?>">Mostrar</a></td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isUser')): ?>
                    <td><a class="btn btn-primary" href="/books/<?php echo e($book->id); ?>/edit">Editar</a></td>
                    <?php endif; ?>
                    <td>
                        <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('isUser')): ?>
                            <button class="btn btn-danger" onclick="return confirm('¿Deseas Borrarlo?')" type="submit">Borrar</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    No se han encontrado libros.
                </div>
                <?php endif; ?>
            
        </tbody>
        
    </table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('book.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/book/index.blade.php ENDPATH**/ ?>