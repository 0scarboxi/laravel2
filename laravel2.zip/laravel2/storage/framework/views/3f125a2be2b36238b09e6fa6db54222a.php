<?php $__env->startSection('titulopagina'); ?>
    Editar libro
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <form method="post" action="<?php echo e(route('books.update', $book->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <!-- Titulo input-->
        <div class="form-floating mb-3">
        <input class="form-control" name="titulo" type="text" value="<?php echo e($book->titulo ?? old('titulo')); ?>"/>
        <label for="name">Titulo</label>

        <!-- Autor input-->
        <div class="form-floating mb-3">
            <input class="form-control" name="descripcion" type="text" value="<?php echo e($book->descripcion ?? old('descripcion')); ?>" />
            <label for="name">Autor</label>
        </div>
        <!-- Fecha pub input-->
        <div class="form-floating mb-3">
            <input class="form-control" name="fechapub" type="date" value="<?php echo e($book->fechapub ?? old('fechapub')); ?>" />
            <label for="name">Fecha Publicacion</label>
        </div>
        <!-- Fecha pub GENERO-->
        <div class="form-floating mb-3">
            <input class="form-control" name="genero" type="text" value="<?php echo e($book->genero ?? old('genero')); ?>" />
            <label for="name">Genero</label>
        </div>
        <!-- Fecha pub NUMPAG-->
        <div class="form-floating mb-3">
            <input class="form-control" name="numpag" type="number" value="<?php echo e($book->numpag ?? old('numpag')); ?>" />
            <label for="name">Numero de paginas</label>
        </div>
        
        <!-- Submit Button-->

        <button type="submit" class="btn btn-primary">Guardar cambios</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('book.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/book/edit.blade.php ENDPATH**/ ?>