<?php $__env->startSection('titulopagina'); ?>
    Listado General de clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<br>
<a class="btn btn-primary" href="<?php echo e(route('clientes.create')); ?>">Crear Cliente</a>
<br>
<br>

<?php if(session('exito')): ?>
<br>
<div class="alert alert-success">
    <?php echo e(session('exito')); ?>

</div>
<?php endif; ?>

<table class="table">
    <thead class="table-dark">
        <tr>
            <td>Nombre</td>
            <td>RUT</td>
            <td>Teléfonos</td>
            <td>Calle</td>
            <td>Ciudad</td>
            <td>Número</td>
            <td>Comuna</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    </thead>

    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($cliente->nombre); ?></td>
            <td><?php echo e($cliente->rut); ?></td>
            <td>
                <?php $__currentLoopData = json_decode($cliente->telefonos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($telefono); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
            <td><?php echo e($cliente->calle); ?></td>
            <td><?php echo e($cliente->ciudad); ?></td>
            <td><?php echo e($cliente->numero); ?></td>
            <td><?php echo e($cliente->comuna); ?></td>
            <td><a class="btn btn-primary" href="/clientes/<?php echo e($cliente->rut); ?>">Mostrar</a></td>
            <td><a class="btn btn-primary" href="/ventas/<?php echo e($cliente->id); ?>">Mostrar ventas</a></td>
            <td><a class="btn btn-primary" href="/clientes/<?php echo e($cliente->rut); ?>/edit">Editar</a></td>
            <td>
                <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" onclick="return confirm('¿Deseas Borrarlo?')">Borrar</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-danger">
            No se han encontrado clientes.
        </div>
    <?php endif; ?>
</tbody>

    
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cliente.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel2/resources/views/cliente/index.blade.php ENDPATH**/ ?>