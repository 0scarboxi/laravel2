<?php $__env->startSection('titulopagina'); ?>
    Editar los datos de Cliente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<br>
<br>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <pre>
            <?php echo e($error); ?>

        </pre>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<form action="<?php echo e(route('clientes.update',$cliente->rut)); ?>" method="post">
<?php echo method_field('PUT'); ?> 
<?php echo csrf_field(); ?>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="rut" type="text" value="<?php echo e($cliente->rut ?? old('rut')); ?>" >
                                <label for="rut">RUT</label>
                                <?php $__errorArgs = ['rut'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
                            </div>
                            <div class="form-floating mb-3">
                            <input class="form-control" name="nombre" type="text" value="<?php echo e($cliente->nombre ?? old('nombre')); ?>" >
                                <label for="nombre">Nombre</label>
                                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="calle" type="text" value="<?php echo e($cliente->calle ?? old('calle')); ?>" require>
                                <label for="calle">Calle</label>
                                <?php $__errorArgs = ['calle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="numero" type="integer" value="<?php echo e($cliente->numero ?? old('numero')); ?>" require>
                                <label for="numero">Número</label>
                                <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="ciudad" type="text" value="<?php echo e($cliente->ciudad ?? old('ciudad')); ?>" require>
                                <label for="ciudad">Ciudad</label>
                                <?php $__errorArgs = ['ciudad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-floating mb-3">
                                <input class="form-control" name="comuna" type="text" value="<?php echo e($cliente->comuna ?? old('comuna')); ?>" require>
                                <label for="comuna">Comuna</label>
                                <?php $__errorArgs = ['comuna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div id="telefonos">
    <?php $__currentLoopData = json_decode($cliente->telefonos ?? old('telefonos')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input type="tel" class="form-control" name="telefonos[]" placeholder="<?php echo e($telefono); ?>" value="<?php echo e($telefono); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
            <button type="button" onclick="nuevoTelefono()">Introduzca un número de telefono</button>
            <script>
                let telefonoCount=0;
            function nuevoTelefono() {
                const divTelefonos = document.getElementById('telefonos');
                const input = document.createElement('input');
                input.type = 'tel';
                input.name = 'telefonos[]';
                telefonoCount++;
                input.placeholder = 'Número de telefono '+telefonoCount;
                divTelefonos.appendChild(input);
            }
            </script>
                            <br>
                            <br>
                            <!-- Submit Button-->
                             <button class="btn btn-primary" type="submit">Guardar Cambios</button>
                             <a style="margin-left:50%;" class="btn btn-primary" href="/clientes">Volver</a>
                        </form>
                        <br>
                        
                        <br>
                        <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel2\resources\views/cliente/edit.blade.php ENDPATH**/ ?>