<div>
    <h1>Detalles de la Foto</h1>
    <p>ID de la Foto: <?php echo e($id); ?></p>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/show.blade.php ENDPATH**/ ?>