<div>
    soy el index
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/resources/views/photo/index.blade.php ENDPATH**/ ?>