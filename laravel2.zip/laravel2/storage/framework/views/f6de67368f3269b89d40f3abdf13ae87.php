<?php $__env->startSection('titulopagina'); ?>
    Detalle del Cliente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
   

    <div class="card">
        <div class="card-header">
            <h2>Detalles del Cliente: <?php echo e($cliente->nombre); ?></h2>
        </div>
        <div class="card-body">
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><strong>Nombre:</strong> <?php echo e($cliente->nombre); ?></li>
                <li class="list-group-item"><strong>RUT:</strong> <?php echo e($cliente->rut); ?></li>
                <li class="list-group-item"><strong>Teléfonos:</strong>
                    <ul>
                        <?php $__currentLoopData = json_decode($cliente->telefonos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($telefono); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li class="list-group-item"><strong>Calle:</strong> <?php echo e($cliente->calle); ?></li>
                <li class="list-group-item"><strong>Ciudad:</strong> <?php echo e($cliente->ciudad); ?></li>
                <li class="list-group-item"><strong>Número:</strong> <?php echo e($cliente->numero); ?></li>
                <li class="list-group-item"><strong>Comuna:</strong> <?php echo e($cliente->comuna); ?></li>
            </ul>
            
        </div>
        
    </div>
    <br>
    <a class="btn btn-primary" href="<?php echo e(route('clientes.index')); ?>">Volver al Listado</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cliente.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel2\resources\views/cliente/show.blade.php ENDPATH**/ ?>