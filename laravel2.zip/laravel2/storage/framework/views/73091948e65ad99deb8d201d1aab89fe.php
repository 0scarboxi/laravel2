<?php $__env->startSection('titulopagina'); ?>
   Crear Nuevo Cliente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
<br>
<br>

<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <pre>
            <?php echo e($error); ?>

        </pre>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
        <br>
        <form action="<?php echo e(route('clientes.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            
            <div class="form-floating mb-3">
                <input class="form-control" name="nombre" type="text" value="<?php echo e(old('nombre')); ?>"/>
                <label for="nombre">Nombre</label>
            </div>
            
            <div class="form-floating mb-3">
                <input class="form-control" name="rut" type="text" value="<?php echo e(old('rut')); ?>" />
                <label for="rut">RUT</label>
            </div>
            
            <div class="form-floating mb-3">
                <input class="form-control" name="calle" type="text" value="<?php echo e(old('calle')); ?>" />
                <label for="calle">Calle</label>
            </div>
            
            <div class="form-floating mb-3">
                <input class="form-control" name="numero" type="text" value="<?php echo e(old('numero')); ?>" />
                <label for="numero">Número</label>
            </div>
            
            <div class="form-floating mb-3">
                <input class="form-control" name="ciudad" type="text" value="<?php echo e(old('ciudad')); ?>" />
                <label for="ciudad">Ciudad</label>
            </div>
            
            <div class="form-group">
                <label for="comuna">Comuna</label>
                <select id="lista"  class="form-control" name="comuna">
                    <option value="Ocasional" <?php if(old('comuna') == 'Ocasional'): ?> selected <?php endif; ?>>Ocasional</option>
                    <option value="Regular" <?php if(old('comuna') == 'Regular'): ?> selected <?php endif; ?>>Regular</option>
                    <option value="Frecuente" <?php if(old('comuna') == 'Frecuente'): ?> selected <?php endif; ?>>Frecuente</option>
                    <option value="Embajadores" <?php if(old('comuna') == 'Embajadores'): ?> selected <?php endif; ?>>Embajadores</option>
                </select>
            </div>

            <div id="telefonos">

            </div>
            <button type="button" onclick="nuevoTelefono()">Introduzca un número de telefono</button>

            <button class="btn btn-primary" type="submit">Crear Cliente</button>
            <script>
                let telefonoCount=0;
            function nuevoTelefono() {
                const divTelefonos = document.getElementById('telefonos');
                const input = document.createElement('input');
                input.type = 'tel';
                input.name = 'telefonos[]';
                telefonoCount++;
                input.placeholder = 'Número de telefono '+telefonoCount;
                divTelefonos.appendChild(input);
            }
            </script>
        </form>
        <br>
                        
                        <br>
                        <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cliente.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel2\resources\views/cliente/create.blade.php ENDPATH**/ ?>