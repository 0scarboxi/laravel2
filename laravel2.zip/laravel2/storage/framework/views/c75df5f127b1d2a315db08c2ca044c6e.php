<div>
        <!--🟢 Footer-->
        <footer class="footer text-center">
            <div class="container">
                <div class="row">
                    <!-- Footer Location-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Trabajo creado por:</h4>
                        <p class="lead mb-0">
                            Oscar,Christian,Carlos
                            <br />
                            <br />
                        </p>
                    </div>
                    <!-- Footer Social Icons-->
                    <div class="col-lg-4 mb-5 mb-lg-0">
                        <h4 class="text-uppercase mb-4">Informacion de los clientes</h4>
                    </div>
                    <!-- Footer About Text-->
                    <div class="col-lg-4">
                        <p class="lead mb-0">
                            Volver a la paguina principal
                            <a href="http://laravel2.local/">volver</a>
                            .
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- 🔴 Footer-->
</div>
<?php /**PATH C:\xampp\htdocs\laravel2\resources\views/cliente/common/footer.blade.php ENDPATH**/ ?>