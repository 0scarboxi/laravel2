<?php $__env->startSection('titulopagina'); ?>
    Listado General de ventas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php if(session('exito')): ?>
<br>
<div class="alert alert-success">
    <?php echo e(session('exito')); ?>

</div>
<?php endif; ?>
<div class="card-header">
            <h2>Ventas del Cliente: <?php echo e($cliente->nombre); ?></h2>
        </div>
<table class="table">
    <thead class="table-dark">
        <tr>
            <td>ID</td>
            <td>Fecha</td>
            <td>Cliente</td>
            <td>Descuento</td>
            <td>Monto final</td>
            <td></td>
        </tr>
    </thead>

    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($venta->id); ?></td>
            <td><?php echo e($venta->fecha); ?></td>
            <td><?php echo e($venta->cliente->rut); ?></td>
            <td><?php echo e($venta->descuento); ?></td>
            <td><?php echo e($venta->monto_final); ?></td>
            <td>
            </td>
        </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert alert-danger">
            No se han encontrado ventas.
        </div>
    <?php endif; ?>
    
</tbody>

    
</table>
<a class="btn btn-primary" href="<?php echo e(route('clientes.index')); ?>">Volver al Listado</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('venta.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel2\resources\views/venta/show.blade.php ENDPATH**/ ?>