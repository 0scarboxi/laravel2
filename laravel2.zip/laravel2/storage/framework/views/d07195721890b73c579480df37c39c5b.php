<?php echo e($slot); ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>